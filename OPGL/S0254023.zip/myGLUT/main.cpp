#include <GL/glut.h>
#include <time.h>
#include <math.h>

const int n = 100;
const GLfloat R = 0.5f;
const GLfloat Pi = 3.1415926536f;
static GLfloat angle = 2*Pi;
static GLfloat spin = 0.0;

float m_sec(struct tm *ptr){
    return ((Pi/2)-(((float)ptr ->tm_sec)/60)* 2 * Pi);
}
float m_min(struct tm *ptr){
    return ((Pi/2)- ((ptr ->tm_min + ptr ->tm_sec / 60)/60) * 2 * Pi);
}
float m_hour(struct tm *ptr){
    if(0 < ptr -> tm_hour && ptr -> tm_hour < 12)
        return ((Pi/2)-( (float)ptr ->tm_hour + ptr ->tm_min / 60.0)/12 * 2 *Pi);
    else
        return ((Pi/2)-((ptr ->tm_hour - 12.0 + ptr ->tm_min / 60.0)/12) * 2 * Pi);
}

void keyboard(int key, int x, int y){
    switch(key){
        case GLUT_KEY_LEFT :
            spin = spin + 0.1;
            break;
        case GLUT_KEY_RIGHT :
            spin = spin - 0.1;
            break;
    }
}

void myDisplay(void){
    struct tm *ptr;
    time_t t;
    t = time(NULL);
    ptr = localtime(&t);

    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_BLEND);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3f(0.5, 0.5, 0.5);               //�}�l�e���������
    glBegin(GL_POLYGON);
	for(int i=0; i<n; ++i)
		glVertex2f(R*cos(2*Pi/n*i), R*sin(2*Pi/n*i));
    glEnd();

    glPointSize(7.0f);
    glColor3f(0.0, 0.0, 0.0);               //�}�l�e�ɰw
    glBegin(GL_LINES);
    glRotatef((angle/3600.0), 0.0, 0.0, 1.0);
    glVertex2f(0.0, 0.0);
    glVertex2f(cos(m_hour(ptr) + spin/60) * R * 0.55, sin(m_hour(ptr) + spin/60) * R * 0.55);
    glEnd();

    glPointSize(5.0f);
    glColor3f(0.0, 0.0, 0.0);               //�}�l�e���w
    glBegin(GL_LINES);
    glRotatef((angle/60.0)+spin, 0.0, 0.0, 1.0);
    glVertex2f(0.0, 0.0);
    glVertex2f(cos(m_min(ptr) + spin) * R * 0.65, sin(m_min(ptr) + spin) * R * 0.65);
    glEnd();

    glPointSize(3.0f);
    glColor3f(0.0, 0.0, 0.0);               //�}�l�e���w
    glBegin(GL_LINES);
    glRotatef(angle, 0.0, 0.0, 1.0);
    glVertex2f(0.0, 0.0);
    glVertex2f(cos(m_sec(ptr)) * R * 0.85, sin(m_sec(ptr)) * R * 0.85);
    glEnd();

    glFlush();
    }

void idle(void){
    angle -= ((2*Pi)/60);
    Sleep(10);
    if(angle < 0.0f){
        angle = 2 * Pi;
    }
    myDisplay();
}


int main(int argc, char *argv[]){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
	glutInitWindowPosition(300, 100);
	glutInitWindowSize(400, 400);
	glutCreateWindow("Clock");
	glutDisplayFunc(myDisplay);
	glutSpecialFunc(keyboard);
	glutIdleFunc(idle);
	glutMainLoop();

	return 0;
}
