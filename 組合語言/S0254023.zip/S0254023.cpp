#include <iostream>
using namespace std;

void selection_sort(int a[], int n){
    for(int i = 0; i < n; i++){
        int index = i;
        for(int j = i + 1; j < n ; j++){
            if(a[j] < a[index]){
                index = j;
            }
        }
        int temp = a[i];
        a[i] = a[index];
        a[index] = temp;
    }
}

int main(){
    int a[10], n;
    cout << "�п�J���X�ӼƦr(�p��10):" << endl ; 
    cin >> n;
    cout << "�п�J�@��Ʀr:" << endl ;
    for(int i = 0 ; i < n; i ++){
        cin >> a[i];
    }
    selection_sort(a, n);
    cout << "�Ƨǫᵲ�G:" << endl; 
    for(int i = 0 ; i < n; i++) {
        cout << a[i] << " ";
    }
    cin.get();
    cin.get();
    return 0;
}

